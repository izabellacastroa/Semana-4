﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Ingrear salario anual: ");
        double salarioAnual = Convert.ToDouble(Console.ReadLine());

        double impuesto = 0;

        if (salarioAnual <= 30000)
        {
            impuesto = salarioAnual * 0.1;
        }
        else if (salarioAnual <= 60000)
        {
            impuesto = salarioAnual * 0.2;
        }
        else
        {
            impuesto = salarioAnual * 0.3;
        }

        Console.WriteLine($"El ISR a pagar es: {impuesto}");
    }
}

